import java.lang.*;
class MainClass {
	public static void main(String [] args){
		System.out.println("Hola Mundo, Soy Quirino");
	}
}